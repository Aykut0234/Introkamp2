<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Form;

class FormValidtionController extends Controller
{
    // Create Form
    public function createUserForm(Request $request)
    {
        return view('form');
    }

    // Store Form data in database
    public function userForm(Request $request)
    {
      $this->validate($request, [
        // Voeg hier je validatieregels toe
    ]);

    // Sla de data op in de database
    $form = new Form([
        'name' => $request->input('name'),
        'class' => $request->input('class'),
        'birthdate' => $request->input('birthdate'),
        'phone' => $request->input('phone'),
        'is_coming' => $request->input('is_coming'),
        'emergency_contactname' => $request->input('emergency_contactname'),
        'emergency_contactnumber' => $request->input('emergency_contactnumber'),
        'emergency_contactrelationship' => implode(', ', $request->input('emergency_contactrelationship')),
        'dietary_requirements' => json_encode($request->input('dietary_requirements')),
        'more_important' => $request->input('more_important'),
        'medicine' => $request->input('medicine'),
        'allergies' => $request->input('allergies'),
    ]);

    $form->save();

    return back()->with('success', 'Your form has been submitted.');
    }

    public function showBijzonderheden()
    {
        $forms = Form::all();
        return view('bijzonderheden', compact('forms'));
    }

    public function showTable()
    {
        $forms = Form::orderBy('class')->orderBy('name')->get();
        if ($forms->isEmpty()) {
            return back()->with('error', 'No form responses found.');
        }
    
     
    
        return view('table', compact('forms'));
    }

    public function showDieetView()
{
    $forms = Form::whereNotNull('dietary_requirements')->get();

    return view('dieet', compact('forms'));
}

}
