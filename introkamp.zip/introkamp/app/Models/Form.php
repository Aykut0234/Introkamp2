<?php
namespace App\Models;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
class Form extends Model
{
    use HasFactory;
    public $fillable = [
        'name',
        'class',
        'birthdate',
        'phone',
        'is_coming',
        'emergency_contactname',
        'emergency_contactnumber',
        'emergency_contactrelationship',
        'dietary_requirements',
        'more_important',
        'medicine', 
        'allergies'

    ];
}