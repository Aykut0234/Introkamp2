

<?php $__env->startSection('content'); ?>
    <div class="container">
        <h1>Tabel met leerlingen</h1>
        <table class="table">
            <thead>
                <tr>
                    <th class="table-header">Klas</th>
                    <th class="table-header">Naam</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $forms; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $form): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td class="table-cell"><?php echo e($form->class); ?></td>
                        <td class="table-cell"><?php echo e($form->name); ?></td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>
<?php $__env->stopSection(); ?>

<style>
    .table {
    width: 100%;
    border-collapse: collapse;
    margin-top: 20px;
}

.table-header {
    background-color: #f2f2f2;
    color: #333;
    font-weight: bold;
    padding: 10px;
    text-align: left;
}

.table-cell {
    padding: 10px;
    border-bottom: 1px solid #ccc;
}

.table-cell:first-child {
    border-right: 1px solid #ccc;
}


</style>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\introkamp\resources\views/table.blade.php ENDPATH**/ ?>