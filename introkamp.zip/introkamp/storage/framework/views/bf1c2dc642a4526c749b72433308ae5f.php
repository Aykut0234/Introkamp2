<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
<head>
     <link href="<?php echo e(asset('css/table.css')); ?>" rel="stylesheet">
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <title>Your App Title</title>

    <!-- Stijlen -->
    <?php echo $__env->yieldContent('styles'); ?>
</head>
<body>
    <div class="container">
        <!-- Inhoud van de pagina -->
        <?php echo $__env->yieldContent('content'); ?>
    </div>

    <!-- Scripts -->
    <?php echo $__env->yieldContent('scripts'); ?>
</body>
</html>
<?php /**PATH C:\laragon\www\introkamp\resources\views/layouts/app.blade.php ENDPATH**/ ?>