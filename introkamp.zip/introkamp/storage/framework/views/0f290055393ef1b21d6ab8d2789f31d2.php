

<?php $__env->startSection('content'); ?>
    <div class="container">
        <h1>Bijzonderheden van leerlingen</h1>
        <table class="table" style="width: 100%; border-collapse: collapse; margin-top: 20px;">
            <thead>
                <tr>
                    <th style="background-color: #f2f2f2; font-weight: bold; padding: 10px; text-align: center;">Klas</th>
                    <th style="background-color: #f2f2f2; font-weight: bold; padding: 10px; text-align: center;">Naam</th>
                    <th style="background-color: #f2f2f2; font-weight: bold; padding: 10px; text-align: center;">Bijzonderheden over eten</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $forms; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $form): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php
                        $dietaryRequirements = json_decode($form->dietary_requirements);
                    ?>
                    <?php if($dietaryRequirements): ?>
                        <tr>
                            <td style="padding: 10px; text-align: center;"><?php echo e($form->class); ?></td>
                            <td style="padding: 10px; text-align: center;"><?php echo e($form->name); ?></td>
                            <td style="padding: 10px; text-align: center;">
                                <?php $__currentLoopData = $dietaryRequirements; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $requirement): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php echo e(html_entity_decode($requirement)); ?>

                                    <?php if($key < count($dietaryRequirements) - 1): ?>
                                        ,
                                    <?php endif; ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </td>
                        </tr>
                    <?php endif; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\introkamp\resources\views/dieet.blade.php ENDPATH**/ ?>