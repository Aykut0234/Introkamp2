

<?php $__env->startSection('content'); ?>
    <div class="container">
        <h1>Bijzonderheden van leerlingen</h1>
        <table class="table" style="width: 100%; border-collapse: collapse; margin-top: 20px;">
            <thead>
                <tr>
                    <th style="background-color: #f2f2f2; font-weight: bold; padding: 10px; text-align: center;">Klas</th>
                    <th style="background-color: #f2f2f2; font-weight: bold; padding: 10px; text-align: center;">Naam</th>
                    <th style="background-color: #f2f2f2; font-weight: bold; padding: 10px; text-align: center;">Allergie</th>
                    <th style="background-color: #f2f2f2; font-weight: bold; padding: 10px; text-align: center;">Medicijnen</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $forms; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $form): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td style="padding: 10px; text-align: center;"><?php echo e($form->class); ?></td>
                        <td style="padding: 10px; text-align: center;"><?php echo e($form->name); ?></td>
                        <td style="padding: 10px; text-align: center;">
                            <?php echo e($form->allergies ?? 'Geen'); ?>

                        </td>
                        <td style="padding: 10px; text-align: center;">
                            <?php echo e($form->medicine ?? 'Geen'); ?>

                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\introkamp\resources\views/bijzonderheden.blade.php ENDPATH**/ ?>