<?php
use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;
class CreateFormsTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('forms', function (Blueprint $table) {
            $table->id();
            $table->string('name');
            $table->string('class');
            $table->date('birthdate');
            $table->string('phone');
            $table->string('is_coming');
            $table->string('emergency_contactname');
            $table->string('emergency_contactnumber');
            $table->string('emergency_contactrelationship')->nullable();
            $table->string('dietary_requirements')->nullable();
            $table->string('more_important');
            $table->string('medicine');
            $table->string('allergies');
            $table->text('message')->nullable();
            $table->timestamps();
        });
    }
    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('forms');
    }
}
