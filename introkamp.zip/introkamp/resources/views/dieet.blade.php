@extends('layouts.app')

@section('content')
    <div class="container">
        <h1>Bijzonderheden van leerlingen</h1>
        <table class="table" style="width: 100%; border-collapse: collapse; margin-top: 20px;">
            <thead>
                <tr>
                    <th style="background-color: #f2f2f2; font-weight: bold; padding: 10px; text-align: center;">Klas</th>
                    <th style="background-color: #f2f2f2; font-weight: bold; padding: 10px; text-align: center;">Naam</th>
                    <th style="background-color: #f2f2f2; font-weight: bold; padding: 10px; text-align: center;">Bijzonderheden over eten</th>
                </tr>
            </thead>
            <tbody>
                @foreach ($forms as $form)
                    @php
                        $dietaryRequirements = json_decode($form->dietary_requirements);
                    @endphp
                    @if ($dietaryRequirements)
                        <tr>
                            <td style="padding: 10px; text-align: center;">{{ $form->class }}</td>
                            <td style="padding: 10px; text-align: center;">{{ $form->name }}</td>
                            <td style="padding: 10px; text-align: center;">
                                @foreach ($dietaryRequirements as $key => $requirement)
                                    {{ html_entity_decode($requirement) }}
                                    @if ($key < count($dietaryRequirements) - 1)
                                        ,
                                    @endif
                                @endforeach
                            </td>
                        </tr>
                    @endif
                @endforeach
            </tbody>
        </table>
    </div>
@endsection
