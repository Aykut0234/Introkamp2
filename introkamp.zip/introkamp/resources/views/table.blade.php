@extends('layouts.app')

@section('content')
    <div class="container">
        <h1>Tabel met leerlingen</h1>
        <table class="table">
            <thead>
                <tr>
                    <th class="table-header">Klas</th>
                    <th class="table-header">Naam</th>
                </tr>
            </thead>
            <tbody>
                @foreach ($forms as $form)
                    <tr>
                        <td class="table-cell">{{ $form->class }}</td>
                        <td class="table-cell">{{ $form->name }}</td>
                    </tr>
                @endforeach
            </tbody>
        </table>
    </div>
@endsection

<style>
    .table {
    width: 100%;
    border-collapse: collapse;
    margin-top: 20px;
}

.table-header {
    background-color: #f2f2f2;
    color: #333;
    font-weight: bold;
    padding: 10px;
    text-align: left;
}

.table-cell {
    padding: 10px;
    border-bottom: 1px solid #ccc;
}

.table-cell:first-child {
    border-right: 1px solid #ccc;
}


</style>
