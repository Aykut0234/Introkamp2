
<!DOCTYPE html>
<html lang="{{ str_replace('_', '-', app()->getLocale()) }}">
<head>
    <h1>Curio</h1>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    
    <title>Curio introkamp</title>
    
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.1/dist/css/bootstrap.min.css">
    <link rel="stylesheet" href="{{asset('css/style.css') }}">
</head>
<body>
    <div class="container mt-5">
        @if(Session::has('success'))
            <div class="alert alert-success text-center">
                {{Session::get('success')}}
            </div>
        @endif    
        <form method="post" action="{{ route('validate.form') }}" novalidate>
            @csrf
            <div class="form-group mb-2">
             <h1>Introkamp formulier</h1>
                <label>Naam</label>
                <input type="text" class="form-control @error('name') is-invalid @enderror" name="name" id="name"><br>
                @error('name')
                    <span class="invalid-feedback" role="alert">
                        <strong>{{ $message }}</strong>
                    </span>
                @enderror
            </div>

            <div class="form-group mb-2">
                <label>Geboortedatum</label>
                <input type="date" class="form-control @error('birthdate') is-invalid @enderror" name="birthdate" id="birthdate">
                @error('birthdate')<br>
                    <span class="invalid-feedback" role="alert">
                        <strong>{{ $message }}</strong>
                    </span>
                @enderror
            </div>

            <div class="form-group mb-2">
                <label>Klas</label><br>
                <select name="class">
                    <option value="" disabled selected>Kies je klas!</option>
                    <option value="SSD1A">SSD1A</option>
                    <option value="SSD1B">SSD1B</option>
                    <option value="SSD1C">SSD1C</option>
                    <option value="SSD1D">SSD1D</option>
                    <option value="SSD2E">SSD2E</option>
                </select>
            </div>

            <div class="form-group mb-2">
                <label>Telefoonnummer</label>
                <input type="text" class="form-control @error('phone') is-invalid @enderror" name="phone" id="phone">
                @error('phone')<br>
                    <span class="invalid-feedback" role="alert">
                        <strong>{{ $message }}</strong>
                    </span>
                @enderror
            </div>

            <div class="form-group mb-2">
                <label>Ga je mee?</label>
                <input type="text" class="form-control @error('is_coming') is-invalid @enderror" name="is_coming" id="is_coming">
                @error('is_coming')<br>
                    <span class="invalid-feedback" role="alert">
                        <strong>{{ $message }}</strong>
                    </span>
                @enderror
            </div>

            <div class="form-group mb-2">
                <label>Voor- en achternaam noodcontactpersoon</label>
                <textarea class="form-control @error('emergency_contactname') is-invalid @enderror" name="emergency_contactname" id="emergency_contactname" rows="1"></textarea>
                @error('emergency_contactname')<br>
                    <span class="invalid-feedback" role="alert">
                        <strong>{{ $message }}</strong>
                    </span>
                @enderror
            </div>

            <div class="form-group mb-2">
                <label>Telefoonnummer noodcontactpersoon</label>
                <textarea class="form-control @error('emergency_contactnumber') is-invalid @enderror" name="emergency_contactnumber" id="emergency_contactnumber" rows="1"></textarea>
                @error('emergency_contactnumber')<br>
                    <span class="invalid-feedback" role="alert">
                        <strong>{{ $message }}</strong>
                    </span>
                @enderror
            </div>

            <div class="form-group mb-2">
                <label>Relatie met noodcontactpersoon</label><br>
                <label>Ouder/verzorger</label> <input type="checkbox" name="emergency_contactrelationship[]" value="ouder/verzorger" id="emergency_contactrelationship_ouder"><br>
                <label>Partner</label> <input type="checkbox" name="emergency_contactrelationship[]" value="partner" id="emergency_contactrelationship_partner"><br>
                <label>Andere familie</label> <input type="checkbox" name="emergency_contactrelationship[]" value="andere_familie" id="emergency_contactrelationship_andere_familie"><br>
                <label>Anders</label> <input type="checkbox" name="emergency_contactrelationship[]" value="Anders" id="emergency_contactrelationship_anders" onclick="showEmergencyContactRelationshipTextarea()"><br>
                <textarea class="form-control" name="emergency_contactrelationship[]" id="emergency_contactrelationship_anders_textarea" rows="1" style="display: none;"></textarea><br>
            </div>

            <script>
                function showEmergencyContactRelationshipTextarea() {
                    var checkboxAnders = document.getElementById("emergency_contactrelationship_anders");
                    var textareaAnders = document.getElementById("emergency_contactrelationship_anders_textarea");

                    if (checkboxAnders.checked) {
                        textareaAnders.style.display = "block";
                    } else {
                        textareaAnders.style.display = "none";
                    }
                }
            </script>

            <div class="form-group mb-2">
                <label>Dieetwensen</label><br>
                <label>Vegetarisch</label> <input type="checkbox" name="dietary_requirements[]" value="Vegetarisch" id="dietary_requirements_vegetarisch"><br>
                <label>Glutenvrij</label> <input type="checkbox" name="dietary_requirements[]" value="Glutenvrij" id="dietary_requirements_glutenvrij"><br>
                <label>Lactosevrij</label> <input type="checkbox" name="dietary_requirements[]" value="Lactosevrij" id="dietary_requirements_lactosevrij"><br>
                <label>Notenallergie</label> <input type="checkbox" name="dietary_requirements[]" value="Notenallergie" id="dietary_requirements_notenallergie"><br>
                <label>Geen varkensvlees</label> <input type="checkbox" name="dietary_requirements[]" value="Geen_varkensvlees" id="dietary_requirements_geen_varkensvlees"><br>
                <label>Geen</label> <input type="checkbox" name="dietary_requirements[]" value="Geen" id="dietary_requirements_geen"><br>
                <label>Anders</label> <input type="checkbox" name="dietary_requirements[]" value="Anders" id="dietary_requirements_anders" onclick="showDietaryRequirementsTextarea()"><br>
                <textarea class="form-control" name="dietary_requirements[]" id="dietary_requirements_anders_textarea" rows="1" style="display: none;"></textarea><br>
            </div>

            <script>
                function showDietaryRequirementsTextarea() {
                    var checkboxAnders = document.getElementById("dietary_requirements_anders");
                    var textareaAnders = document.getElementById("dietary_requirements_anders_textarea");

                    if (checkboxAnders.checked) {
                        textareaAnders.style.display = "block";
                    } else {
                        textareaAnders.style.display = "none";
                    }
                }
            </script>

            <div class="form-group mb-2">
                <label>Waar moeten we nog meer rekening mee houden?</label>
                <textarea class="form-control @error('more_important') is-invalid @enderror" name="more_important" id="more_important" rows="1"></textarea><br>
                @error('more_important')
                    <span class="invalid-feedback" role="alert">
                        <strong>{{ $message }}</strong>
                    </span>
                @enderror
            </div>

            <div class="form-group mb-2">
                <label>Gebruik je medicijnen? Zo ja, welke?</label>
                <textarea class="form-control @error('medicine') is-invalid @enderror" name="medicine" id="medicine" rows="1"></textarea><br>
                @error('medicine')
                    <span class="invalid-feedback" role="alert">
                        <strong>{{ $message }}</strong>
                    </span>
                @enderror
            </div>

            <div class="form-group mb-2">
                <label>Heb je allergieën? Zo ja, waarvoor?</label>
                <textarea class="form-control @error('allergies') is-invalid @enderror" name="allergies" id="allergies" rows="1"></textarea><br>
                @error('allergies')
                    <span class="invalid-feedback" role="alert">
                        <strong>{{ $message }}</strong>
                    </span>
                @enderror
            </div>

            <div class="d-grid mt-3">
                <input type="submit" name="send" value="Submit" class="btn btn-dark btn-block">
            </div>
        </form>
    </div>
</body>
</html>
