@extends('layouts.app')

@section('content')
    <div class="container">
        <h1>Bijzonderheden van leerlingen</h1>
        <table class="table" style="width: 100%; border-collapse: collapse; margin-top: 20px;">
            <thead>
                <tr>
                    <th style="background-color: #f2f2f2; font-weight: bold; padding: 10px; text-align: center;">Klas</th>
                    <th style="background-color: #f2f2f2; font-weight: bold; padding: 10px; text-align: center;">Naam</th>
                    <th style="background-color: #f2f2f2; font-weight: bold; padding: 10px; text-align: center;">Allergie</th>
                    <th style="background-color: #f2f2f2; font-weight: bold; padding: 10px; text-align: center;">Medicijnen</th>
                </tr>
            </thead>
            <tbody>
                @foreach ($forms as $form)
                    <tr>
                        <td style="padding: 10px; text-align: center;">{{ $form->class }}</td>
                        <td style="padding: 10px; text-align: center;">{{ $form->name }}</td>
                        <td style="padding: 10px; text-align: center;">
                            {{ $form->allergies ?? 'Geen' }}
                        </td>
                        <td style="padding: 10px; text-align: center;">
                            {{ $form->medicine ?? 'Geen' }}
                        </td>
                    </tr>
                @endforeach
            </tbody>
        </table>
    </div>
@endsection
