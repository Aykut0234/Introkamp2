<?php
use Illuminate\Support\Facades\Route;
use App\Http\Controllers\FormValidtionController;
/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/
Route::get('/form', [FormValidtionController::class, 'createUserForm']);
Route::post('/form', [FormValidtionController::class, 'UserForm'])->name('validate.form');
Route::get('/table', [FormValidtionController::class, 'showTable'])->name('table');
Route::get('/bijzonderheden', [FormValidtionController::class, 'showBijzonderheden'])->name('bijzonderheden');
Route::get('/dieet', [FormValidtionController::class, 'showDieetView'])->name('dieet');

